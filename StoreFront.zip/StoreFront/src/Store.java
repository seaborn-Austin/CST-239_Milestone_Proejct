import java.util.Arrays;
import java.util.Collection;
import java.util.ArrayList;

public class Store {
	
	private String name;

	private int quantity;
	protected int inventory;
	protected int cart;
	//protected int price;
	private ArrayList<SalableProduct> product = new ArrayList<SalableProduct>();
	//private SalableProduct[] product = new SalableProduct[100]; 
	private ArrayList<SalableProduct> shoppingCart = new ArrayList<SalableProduct>();
	//private SalableProduct[] shoppingCart = new SalableProduct[100];
	
	
	/*
	 * Constructor for Store
	 * */
	/**
	 * 
	 * @param name
	 */
	public Store(String name)
	{
		
		this.name = name;
	}
	
	
	/*
	 * Displays the name of the store
	 * */
	/**
	 * 
	 * @return
	 */
	public String displayName()
	{
		return "Welcome to " + this.name + "!\n";
	}
	
	/*
	 * Function to add items to cart
	 * */
	/**
	 * 
	 * @param n
	 * @param quantity
	 * @param d
	 */
//	public void addToStore(String n, int quantity, String d, int p)
//	{
//		// 1/4/2022
//		//The previous logic would not have worked since I was referencing the name variable.
//		// The name variable is applicable to the name of the store and not the name of the item
//		// I was trying to assign the name variable to the item, which is incorrect because 
//		// name is also in reference to the store name.
//		// I changed item from a type of String to the name of the item
//			this.quantity += quantity;
//			product.add(inventory, new SalableProduct(n, d, quantity, p)); 
//						
//		/*
//		 * Update the array index.
//		 * */
//		updateInventory();
//		//System.out.println("Global quantity is: " + this.quantity);
//		System.out.println(quantity + " " + n + ", a " + d  + " item," + " was added to " + this.name + ".");
//		
//	}
	
	public void addToStore(int quantity, Object o)
	{
		// 1/4/2022
		//The previous logic would not have worked since I was referencing the name variable.
		// The name variable is applicable to the name of the store and not the name of the item
		// I was trying to assign the name variable to the item, which is incorrect because 
		// name is also in reference to the store name.
		// I changed item from a type of String to the name of the item
			this.quantity += quantity;
			product.add(inventory, (SalableProduct) o); 
						
		/*
		 * Update the array index.
		 * */
		updateInventory();
		//System.out.println("Global quantity is: " + this.quantity);
		System.out.println(quantity + " " + o.toString());
		
	}
	
	/*
	 * Function to add items to cart
	 * */
	/**
	 * 
	 * @param n
	 * @param q
	 */
	public void addToCart(String n, int q)
	{
		
		
		int i = 0;
		while(i < product.size())
		{
			if(product.contains(n))
			{
				shoppingCart.add(cart, product.get(i));
				cart++;
				removeFromStore(name, q);
			}
			i++;
			
		}
		//shoppingCart[cart] = new SalableProduct(n, q);
				
				
			System.out.println(name + " was added to your cart.");
			displayCart(name);
			displayInventory();
			

	}
	
	/**
	 * Function to add item's back to the cart if the purchase is canceled
	 * @param n
	 * @param q
	 */
	private void addBackToCart(String n, int q)
	{
		shoppingCart.add(cart, new SalableProduct(n, q));
		cart++;
		System.out.println("You added " + q + " " + n + " to your cart.");
	}
	
	/**
	 * Function to cancel the purchase of an item or items.
	 * @param n
	 * @param q
	 */
	public void cancelPurchase(String n, int q)
	{
		System.out.println("Canceling: ");
		
		for(int i = 0; i < shoppingCart.size(); i++)
		{
			if(!(shoppingCart.get(i) == null))
			{
				System.out.println(shoppingCart.get(i).toString() + " at array index " + i);
				
			}
			else
			{
				System.out.println("Canceling order at index " + i + "\n\n");
				addBackToCart(n, q);
				break;
			}
		}
	}
	/*
	 * Function to purchase the items in the cart
	 * */
	/**
	 * 
	 * @param n
	 * @param q
	 */
	public void purchase(String n, int q)
	{
			System.out.println("Purchasing: ");
		
			for(int i = 0; i < shoppingCart.size(); i++)
			{
				if(!(shoppingCart.get(i) == null))
				{
					System.out.println(shoppingCart.get(i).toString() + " at array index " + i);
					
				}
				else
				{
					System.out.println("Processing order at index " + i + "\n\n");
					removeFromCart(n, q);
					break;
				}
			}
		
		
	}
	
	/**
	 * Function to remove items from the cart when item's are purchased
	 * @param name
	 * @param q
	 */
	public void removeFromCart(String name, int q)
	{
		int i = 0;
		while(i < shoppingCart.size())
		{
			if(shoppingCart.get(i).name == name)
			{
				shoppingCart.add(i, new SalableProduct(name, (shoppingCart.get(i).quantity -= q)));
				//shoppingCart[i] = new SalableProduct(name, (shoppingCart[i].quantity -= q));
				break;
			}
			i++;
		}
		System.out.print("Your shopping cart has been updated: \n\n");
		for(i = 0; i < shoppingCart.size(); i++)
		{
			if(!(shoppingCart.get(i) == null))
			{
				System.out.println(shoppingCart.get(i).toString() + " at array index " + i);
				
			}
			else
			{
				System.out.println("The end of the inventory at index " + i + "\n\n");
				break;
			}
			
		}
		
	}
	
	/*
	 * Function to remove items from inventory whenever they are added to the cart.
	 * */
	/**
	 * 
	 * @param name
	 * @param q
	 */
	@SuppressWarnings({ "unlikely-arg-type", "unchecked" })
	public void removeFromStore(Object o, int q)
	{
		int i = 0;
		while(i < product.size())
		{
			if(product.contains(name))
			{
				int temp = product.get(i).getQuantity() - q;
//				int avail = this.quantity -= q;
//				product.get(i).quantity = avail;
				//product.set(inventory, new SalableProduct(name, (this.quantity - q))); 
				product.get(i).setQuantity(temp);
				break;
			}
			i++;
		}
		System.out.print("The contents in the store have been updated: \n\n");
		for(i = 0; i < product.size(); i++)
		{
			if(!(product.get(i) == null))
			{
				System.out.println(product.get(i).toString() + " at array index " + i);
				
			}
			else
			{
				System.out.println("The end of the inventory at index " + i + "\n\n");
				break;
			}
			
		}
		
	}
	/**
	 * 
	 * Display's the contents in the user's cart
	 */
	@SuppressWarnings("unlikely-arg-type")
	private void displayCart(String name)
	{
		System.out.print("The contents in your cart: \n\n");
		int i = 0;
		while(i < shoppingCart.size())
		{
			//Change line 284 from !(shoppingcart.get(i) == null)
			if(shoppingCart.contains(name))
			{
				System.out.println(shoppingCart.get(i).toString() + " at array index " + i);
				
			}
			else
			{
				System.out.println("The end of the cart at index " + i + "\n\n");
				break;
			}
			i++;
			
		}
	}

	/**
	 * Function to display items in cart
	 */
	@SuppressWarnings("unchecked")
	public void displayInventory()
	{
		System.out.print("The contents in the store: \n\n");
		for(int i = 0; i < product.size(); i++)
		{
			if(!(product.get(i) == null))
			{
				System.out.println(product.get(i).toString() + " at array index " + i + "\n");
				
			}
			else
			{
				System.out.println("The end of the cart at index " + i + "\n\n");
				break;
			}
			
		}
		
	}
	
	
	/**
	 * Function to check if cart is empty
	 * @return
	 */
	public Boolean isCartEmpty()
	{
		boolean result = true;
		for(int i = 0; i < product.size() - 1; i++)
		{
			if(product.toString() == null)
			{
				result = false;
			}
			else result = true;
			
		}
		return result;
	}
	
	
	
	/**
	 * Function to update the inventory.
	 */
	protected void updateInventory()
	{
		inventory++;
	}
}
