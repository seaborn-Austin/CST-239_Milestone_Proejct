
public class Weapon extends SalableProduct {

		
	public Weapon(String name, String description, int quantity, int price) {
		super(name, description, quantity, price);
	}
	
	@Override
	public String toString()
	{
		return "Weapon{" + "Name: " + super.getName() + " Description: "
				+ super.getDescription() + " Qauntity: " + super.getQuantity()
				+ " Price: " + super.getPrice();
	}
}
