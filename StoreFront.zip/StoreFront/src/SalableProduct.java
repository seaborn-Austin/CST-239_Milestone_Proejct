
public class SalableProduct {
	protected String name;
	protected String description;
	protected int quantity;
	protected int price;
	
	public SalableProduct(String name, String description, int quantity, int price)
	{
		this.name = name;
		this.description = description;
		this.quantity = quantity;
		this.price = price;
	}
	
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public SalableProduct(String name, String description, int quantity)
	{
		this.name = name;
		this.description = description;
		this.quantity = quantity;
	}
	
	// 1/4/2022 Created a second constructor for just the name and quantity
	public SalableProduct(String name, int quantity)
	{
		this.name = name;
		this.quantity = quantity;
	}
	
	public String toSalableString()
	{
		return name;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	/**
	 * Function to convert an object into a string, adopted from activity 2.
	 */
	@Override
	public String toString()
	{
		return "Product is " + getClass() + " \nName: " + this.name + " \nQuantity: " + this.quantity + "\nPrice: " + (price * quantity);
	}
	
	/**
	 * equals() function to compare two objects to eachother, adopted from activity 2.
	 */
	@Override
	public boolean equals(Object other)
	{
		if(other == this)
		{
			System.out.println("I am here in other == this");
			return true;
		}
		if(other == null)
		{
			System.out.println("I am here in other == null");
			return false;
		}
		if(getClass() != other.getClass())
		{
			System.out.println("I am here in getClass() != other.getClass()");
			return false;
		}
		
		SalableProduct product = (SalableProduct)other;
		return (this.name == product.name);
	}
	
}
