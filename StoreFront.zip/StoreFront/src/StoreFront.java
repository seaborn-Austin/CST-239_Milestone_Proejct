import java.util.Scanner;

public class StoreFront {

	public static void main(String[] args) {
		
		System.out.println("Starting program ... \n\n");
		
		Store store = new Store("Walmart");
		
		System.out.println("\n\nHello! Welcome to " + store.displayName() + "\nWe have the below items for sale!\n\n");
		
		Weapon shotgun = new Weapon("Shotgun", "12 gauge", 50, 200);
		Weapon grenade = new Weapon("Grenade", "Explosive", 100, 300);
		Armor kevlarVest = new Armor("Kevlar Vest", "Body armor", 100, 250);
		Armor kevlarHelmet = new Armor("Kevlar Helmet", "Head armor", 100, 200);
		HealthItem tourniquet = new HealthItem("Tourniquet", "Stops bleeding", 50, 20);
		HealthItem bandage = new HealthItem("Bandage", "Prevents further bleeding", 300, 15);
		store.addToStore(50, shotgun);
		store.addToStore(100, grenade);
		store.addToStore(100, kevlarVest);
		store.addToStore(100, kevlarHelmet);
		store.addToStore(50, tourniquet);
		store.addToStore(300, bandage);
		
		System.out.println(" ");
		
		//store.addToCart(shotgun, 20);
		
		
		System.out.println("\n\nWhat would you like to do?\nYou can type 'view' to view the items in the store."
				+ "\nType 'Add to cart' plus the name of the object and the quantity you wish to purchase  to add an item to your cart. "
				+ "\nType 'Purchase' to purchase an item. "
				+ "\nType 'Cancel purchase' to cancel your purchase. "
				+ "\nType 'leave' to leave the store and end the program!\n\n ");
		
		
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		String command;
		
		//store.displayInventory();
		
		while(sc.hasNextLine())
		{
			System.out.println("You entered " + str);
			command = sc.nextLine();
			if(command.equalsIgnoreCase("view"))
			{
				store.displayInventory();
			}
			if(command.equalsIgnoreCase("add to cart"))
			{
				System.out.println("What item would you like to add?\n");
				String name = sc.nextLine();
				System.out.println("\nHow many do you want?");
				int quantity = sc.nextInt();
				store.addToCart(name, quantity);
				continue;
			}
			if(command.equalsIgnoreCase("purchase"))
			{
				System.out.println("What item would you like to purchase?\n");
				String name = sc.nextLine();
				System.out.println("\nHow many " + name + "'s do you want to purchase?");
				int quantity = sc.nextInt();
				store.purchase(name, quantity);
				continue;
			}
			if(command.equalsIgnoreCase("cancel purchase"))
			{
				System.out.println("What item would you like to cancel the purchase of?\n");
				String name = sc.nextLine();
				System.out.println("\nHow many " + name + "'s do you want to cancel the purchase of?");
				int quantity = sc.nextInt();
				store.cancelPurchase(name, quantity);
		}
		}
		//store.addToCart("shotgun", 20);
//		store.addToCart("kevlar vest", 2);
//		store.addToCart("israeli bandage", 10);
//		store.displayCart();
//		store.purchase("shotgun", 20);
//		store.cancelPurchase("shotgun", 20);
		//store.displayInventory();
	}

}
